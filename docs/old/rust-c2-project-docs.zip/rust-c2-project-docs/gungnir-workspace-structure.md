# `gungnir` Workspace Structure

Companion reference to `scenario-crate-narrative.md` and
`verification-capability-table.md`. Describes the Cargo workspace layout
generated in `gungnir-workspace.tar`, how each crate maps to a table
module, and how the agentic development/verification pipeline is wired
into the repo as CI workflows rather than just policy.

## Directory tree

```
gungnir/
├── Cargo.toml                     # workspace root: members + shared deps
├── README.md
├── CONTRIBUTING.md                # points to docs/agentic-workflow.md
│
├── gungnir-core/                  # core: CV/CA/CT motion models
├── gungnir-filters/                # filters: KF, EKF, UKF, PF, IMM, sqrt/UDU, RTS
├── gungnir-association/            # association: NN/GNN, Hungarian/JV, gating, JPDA, MHT
├── gungnir-track/                  # track-manager: init/confirm/coast/delete
├── gungnir-rfs/                    # rfs (new): PHD/CPHD, GLMB/LMB
├── gungnir-fusion-async/           # fusion-async: OOS/multi-rate, concurrency
├── gungnir-track-fusion/           # track-fusion (new): CI/info-matrix fusion, bias
├── gungnir-coord/                  # coord (new): ECEF/ENU/NED/geodetic
├── gungnir-allocation/             # allocation: Bellman/DP assignment
├── gungnir-scenario/                # scenario (new): five-scenario generator
├── gungnir-metrics/                 # metrics (new): MOTA/MOTP, purity/fragmentation
│
├── gungnir-oracle/                  # NEW — differential-test harness (CI gate #1)
├── gungnir-testkit/                 # NEW — shared proptest invariants (CI gate #2)
├── gungnir-fuzz/                    # NEW — fuzz targets: parser + cost-matrix (CI gate #5)
│
├── benches/                         # criterion benches, one per hot path
│   └── README.md
│
├── docs/
│   ├── agentic-workflow.md          # implementer/reviewer/verifier/human-signoff pipeline
│   └── architecture.md              # crate-to-table-module map
│
└── .github/workflows/
    ├── ci.yml                       # fmt, clippy, cargo test — required on every PR
    ├── oracle-diff.yml              # gate #1, paths: filters/association/rfs
    ├── miri.yml                     # gate #3, any PR touching `unsafe`
    ├── loom.yml                     # gate #4, paths: fusion-async only
    ├── fuzz-nightly.yml             # gate #5, scheduled, not per-PR
    └── bench-regression.yml         # gate #6, p99 regression hard-fail
```

Each crate `Cargo.toml` carries a `description` naming its scope, and each
`src/lib.rs` stub cross-references `verification-capability-table.md` for
the pass criteria it will eventually be checked against.

## Crate-to-table-module map

| Crate | Table module | Verified via (per table) |
|---|---|---|
| `gungnir-core` | `core` | Exact-match closed-form vs. `filterpy`/`initcvkf` etc. — synthetic fixture only |
| `gungnir-filters` | `filters` | Relative error / covariance diff vs. `filterpy`/`trackingEKF`/`trackingUKF`/etc. |
| `gungnir-association` | `association` | Exact match / relative error vs. `scipy.linear_sum_assignment`, Stone Soup JPDA/MHT |
| `gungnir-track` | `track-manager` | Exact match on confirm/delete step index vs. Stone Soup initiators/deleters |
| `gungnir-rfs` | `rfs` (new) | Weights/cardinality vs. Stone Soup GM-PHD/GM-CPHD, `trackerPHD` |
| `gungnir-fusion-async` | `fusion-async` | State convergence (OOS/multi-rate) + `loom` (concurrency) |
| `gungnir-track-fusion` | `track-fusion` (new) | State/covariance vs. hand-derived CI; bias recovery within 1e-3 |
| `gungnir-coord` | `coord` (new) | Round-trip + cross-library vs. `pymap3d`, `ecef2enu` |
| `gungnir-allocation` | `allocation` | Exact match on value function vs. textbook-verified DP |
| `gungnir-scenario` | `scenario` (new) | Statistical self-check (Pd/clutter within 2σ) + round-trip fidelity |
| `gungnir-metrics` | `metrics` (new) | Metric values within 1e-3 vs. `motmetrics` |
| `gungnir-oracle` | *(cross-cutting)* | N/A — is the oracle-comparison harness, not a verified capability |
| `gungnir-testkit` | *(cross-cutting)* | N/A — shared proptest invariants consumed by other crates' tests |
| `gungnir-fuzz` | *(cross-cutting)* | N/A — fuzz targets for sensor-ingestion parser, cost-matrix construction |

## Agentic verification gates → CI workflows

Direct mapping from the six-gate verification stack in
`docs/agentic-workflow.md` to the workflow files that enforce them:

| # | Gate | Workflow | Trigger |
|---|---|---|---|
| 1 | Differential testing vs. oracle | `oracle-diff.yml` | PR touching `filters`, `association`, or `rfs` |
| 2 | Property-based invariants (`proptest`) | *(runs as part of `cargo test` in `ci.yml`, library lives in `gungnir-testkit`)* | Every PR |
| 3 | `cargo miri` on `unsafe` | `miri.yml` | Any PR containing `unsafe` in the diff |
| 4 | `loom` exhaustive interleaving | `loom.yml` | PR touching `fusion-async` only |
| 5 | Fuzzing (`cargo-fuzz`) | `fuzz-nightly.yml` | Scheduled nightly, not per-PR |
| 6 | Benchmark regression gate | `bench-regression.yml` | Every PR |

`fusion-async` (concurrency) and any `unsafe` block are the two items the
workflow doc marks human-owned/low-trust — both get their own dedicated,
always-required workflow rather than being folded into general CI, and
both require explicit human sign-off in addition to a green check.

## Naming notes

- **`gungnir`** is unclaimed on crates.io as of this check (unlike an
  earlier candidate, `sextant`, whose bare name is taken) — a facade crate
  named plain `gungnir` re-exporting the sub-crates is possible if wanted.
- All 14 sub-crate names (`gungnir-core` through `gungnir-fuzz`) were
  confirmed available on crates.io at generation time.
- GitHub org/repo name (`github.com/<org>/gungnir`) was **not** verified
  due to API rate-limiting during the check — confirm manually before
  publishing.
