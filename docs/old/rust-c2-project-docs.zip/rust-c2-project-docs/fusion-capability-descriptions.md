# Fusion Workspace — Capability Descriptions (Business Analyst View)

Companion to `capability-descriptions.md` (the original `gungnir` tracking/estimation
reference — unchanged and still authoritative for `core`, `filters`, `association`,
`track-manager`, `rfs`, `fusion-async`, `track-fusion`, `coord`, `allocation`,
`scenario`, and `metrics`) and to `ARCHITECTURE.md` (the technical crate-boundary
reference for the fused workspace).

This version supersedes the first draft of this document. It incorporates an
independent architecture assessment of the fusion workspace design, which validated
the existing service-boundary decisions and identified a substantial set of
capabilities the current design does not yet cover. This document folds that
assessment in, restructured into the same business-analyst format the rest of the
project's capability documentation uses: what a capability does, why the business
cares, and — for capabilities not yet built — what's recommended and how urgently.

## How this document is organized

1. **What exists today** — the fusion-specific capabilities already scaffolded
   (service layer, 3D data ecosystem, UI/application), condensed.
2. **Independent assessment: is the fusion sound?** — a short verdict on the
   architecture as far as it goes, so the gap list below reads as *additions to a
   good foundation*, not a correction of a flawed one.
3. **Capability gaps — recommended additions** — the bulk of this document, organized
   into six capability domains, each capability described in business terms with a
   priority and a recommended crate.
4. **Recommended build increments** — a practical order to close the gaps.
5. **New crate map** — one line per proposed crate, business-facing.
6. **Principal risks if these gaps aren't addressed.**

---

## 1. What Exists Today

### Service Layer

- **Live Tracking Service** — the single door through which detections go in and a
  current track list comes out. Everything else in the application (map, dashboard,
  intercept planner) depends on this capability staying current; a lag or silent drop
  here propagates into every other screen at once without necessarily looking like a
  bug in any one of them.
- **Intercept Planning Service** — turns "here's what's out there" into "here's what
  to do about it": given current tracks and available resources, recommends which
  resource should respond to which track. This is a genuine scheduling decision with
  cost/operational consequences once there are more tracks than resources, and its
  failure mode is quiet — a subtly wrong plan still looks like a reasonable plan.

### 3D Data Ecosystem

- **Point Cloud / Scientific Mesh / Terrain / Asset Ingestion** — loads background
  context (terrain, structures, sensor-coverage volumes) that turns the 3D view from
  an abstract plot into a situational-awareness tool.
- **GPU-Accelerated Point Cloud Registration & Fusion** — aligns and merges
  point-cloud data from multiple sensors into one coherent surface in real time. This
  is the one capability in the ecosystem with no off-the-shelf equivalent — genuinely
  new engineering, not an adopted library.
- **Streaming Large-Scale Terrain/Point-Cloud Tiles** — loads only the level of
  detail the current camera view needs, for datasets too large to load all at once.
  Deliberately deferred until a deployment actually needs site-scale streamed data.

### UI / Application

- **Real-Time Track Dashboard** — always-current 2D list view of every track, reading
  directly from the Tracking Service so it can never disagree with the 3D view about
  what's currently true.
- **3D Situational-Awareness Viewport** — the primary "big picture" screen: tracks,
  terrain, and intercept geometry together, with camera controls.
- **Intercept Planning Panel** — the Intercept Service's current plan, in a form an
  operator can read and act on under time pressure.
- **Sensor Health & Alerting** — surfaces degraded-but-recoverable states (a coasting
  track, a rejected gate, a stale fallback plan) so degradation is visible rather than
  silently absorbed.

---

## 2. Independent Assessment: Is the Fusion Sound?

A structural review of the current design reached a consistent verdict: **the
fusion is a strong technical integration baseline, but not yet a complete
operational solution.** It is, as reviewed, a well-structured *tracking, fusion,
visualization, and allocation engine* — not yet a fully deployable mission
application, sensor-integration platform, governed decision-support system, or
production product.

What the review found sound, specifically:

| Area | Verdict |
|---|---|
| Keeping estimation/tracking math (filters, association, lifecycle, RFS, fusion) as pure Rust, isolated from UI/GPU | Correct protection of numerical logic from presentation-layer coupling |
| The `gungnir-tracking-service` / `gungnir-intercept-service` boundary | The single most important decision in the design — the desktop app depends on stable operational objects (tracks, plans, alerts), never on the internal composition of the tracking stack |
| Splitting `fusion-data` (I/O, unit-testable) from `fusion-data-fusion` (GPU-aware) | Sound — avoids GPU ownership, render state, and ingest logic becoming inseparable, a common real-time-system failure mode |
| The five-scenario verification strategy | A genuine differentiator — it tests integrated failure modes (asynchronous timing, dense cardinality, adversarial geometry) rather than only isolated algorithms |
| `fusion-render` owning one shared `wgpu` device | Correct resource-lifecycle discipline |

In short: the parts that exist are built the right way. The gap is coverage, not
quality — and closing it means adding a product/platform backbone around the engine,
not adding more tracking algorithms or UI panels.

---

## 3. Capability Gaps — Recommended Additions

Organized into six capability domains. Each entry: what it would do, why it matters
to the business, the recommended crate, and a priority (**Critical** / **High** /
**Medium** / **Lower**) reflecting how much the gap limits real deployment versus how
much it's a maturity/scale concern.

### 0. Foundational (needed before most of the domains below can be built well)

**Canonical Operational Data Model** — *Critical* — `fusion-model`

*What it does:* Defines one shared, versioned set of domain types —
`Track`/`Detection`/`Resource`/`InterceptPlan` and friends — with provenance, quality,
identity, timestamps, and classification as first-class fields, owned by one crate
every service and UI layer builds against.

*Why it matters:* Right now these types are only sketched per-service. Without one
canonical model, every new capability below (ingestion, identity, persistence,
decision support) either invents its own overlapping notion of "what a track is," or
gets bolted onto the wrong owner. This is the single highest-leverage gap to close
first — it's the foundation the rest of the list is built on, not a parallel item to
it.

**Event & Durable Messaging** — *High* — `fusion-eventing`

*What it does:* A transport-neutral event interface (in-process channel today, a
durable/replayable log or network stream later) that the Tracking Service, Intercept
Service, and future ingestion/persistence capabilities all publish to and subscribe
from, instead of the UI polling a mutable slice every frame.

*Why it matters:* Polling a live snapshot works for a single-window desktop app. It
does not support persistence, replay, multi-user collaboration, or external system
integration — all of which need "here's what changed and when," not just "here's the
current state." Building this now is materially cheaper than retrofitting it once
several other capabilities already depend on the polling pattern.

**Persistence & Data Lifecycle** — *High* — `fusion-store`

*What it does:* Durable storage for mission sessions, replay artifacts, geospatial
caches, configuration baselines, and audit logs — with an explicit retention/deletion
policy.

*Why it matters:* Currently, once a session ends, nothing about it persists. Any
requirement to review a past session, reproduce an incident, or simply not re-load
the same terrain data on every restart depends on this existing.

**Configuration & Mission Management** — *High* — `fusion-config`, `fusion-mission`

*What it does:* A managed, versioned, validated configuration model for sensor
definitions, filter/association selection, thresholds, allocation weights, terrain
layers, and mission plans — plus session lifecycle (create/load/save/replay/close).

*Why it matters:* Today, sensors and resources are assumed to be supplied
programmatically. Any real deployment needs to add or reconfigure a sensor without a
code change and rebuild — this is normally a baseline expectation for operational
software, not an advanced feature.

### 3.1 Sense, Ingest & Normalize

The current design begins functionally at "a detection arrives." Everything upstream
of that — how a real radar, EO/IR feed, ADS-B/AIS source, lidar, or external C2 system
actually gets data into the application — is currently undefined.

**Real Sensor & External-System Integration** — *Critical* — `fusion-ingest`

*What it does:* Protocol-specific adapters plus a validation/authentication/quarantine
gateway that normalizes live, recorded, and simulated sources into one canonical
observation envelope before anything reaches the Tracking Service.

*Why it matters:* Without this, "detection" is only an internal test-fixture concept.
No number of well-verified filters or associators matters operationally until real
sensor data can actually get into the system safely — malformed, malicious, or
out-of-spec input needs to be caught here, not inside the tracking core.

**Sensor Management & Adaptive Collection** — *High* — `fusion-sensor-management`

*What it does:* A sensor registry (identity, modality, location, calibration version,
operating state) plus tasking, mode management, and coverage planning — not just the
existing UI health *display*, but the management capability behind it.

*Why it matters:* The current design shows sensor health but has no way to actually
task, calibrate, or manage a sensor's operating mode. In any deployment with more than
a handful of fixed sensors, this becomes a real operational gap quickly.

**Time Management & Synchronization** — *Critical* — `fusion-time`

*What it does:* Clock discipline across sensors, explicit source-time vs.
receipt-time semantics, a late-data policy, deterministic replay-time control, and
synchronization health reporting — a formalization of what out-of-sequence handling
already partially does, extended to the whole application rather than just the
fusion-async pipeline internally.

*Why it matters:* Out-of-sequence handling exists inside the tracking core, but a
deployed multi-sensor system needs the *same* time discipline visible and consistent
across ingestion, persistence, and replay — not just inside one crate's internal
buffer.

**Data Quality, Provenance & Confidence Governance** — *High* — extends `fusion-model`
+ `fusion-ingest`

*What it does:* Attaches source lineage, calibration-baseline version, association
confidence, and freshness/latency to every track and observation, with quality gates
before data is displayed, fused, or used for allocation.

*Why it matters:* An operator (or an automated downstream consumer) needs to know not
just "where is it" but "how much should I trust this" — a stale, low-confidence track
displayed with the same visual weight as a fresh, high-confidence one is a real
operational risk, not a cosmetic gap.

### 3.2 Understand & Maintain the Operational Picture

**Identity Management & Track Continuity** — *High* — `fusion-identity`

*What it does:* Persistent global track/entity identity across feeds — aliases,
merge/split history, supersession — beyond the tracking core's internal track IDs.

*Why it matters:* The tracking core manages IDs internally and correctly, but a
multi-system or multi-session deployment needs an identity that survives across
restarts, replays, and external system correlation — "is this the same object we saw
yesterday" is a business question the current design can't answer yet.

**Classification & Identification (Friend/Foe/Unknown)** — *Medium* — a dedicated
identification capability

*What it does:* Assigns and maintains a classification per track — friendly, hostile,
neutral, unknown — from an evidence-fusion process, feeding both the dashboard and
the intercept planner's candidate list.

*Why it matters:* Every track in the current design is purely kinematic (position,
velocity, covariance). In almost any real deployment, "what is it" is at least as
consequential a question as "where is it," and it's what actually drives a response
decision — without it, the Intercept Planning Service can only recommend resources
against tracks indiscriminately.

**Geospatial Reference & Map Service Layer** — *Medium* — `fusion-geo`

*What it does:* Coordinate-reference-system governance, map/imagery layers,
geocoding, vector features, spatial indexing, and geofencing — extending today's
terrain-elevation-only ingestion with visual and functional geospatial context.

*Why it matters:* Elevation data alone gives shape without visual orientation cues —
operators generally orient far faster against recognizable imagery (roads,
coastlines, buildings) than bare terrain geometry. This is a well-understood
usability gap for any geospatial situational-awareness tool.

**Advanced 3D Analytical Functions** — *Medium* — standalone analytical services
(CPU/GPU), rendered by `fusion-viewport3d` rather than embedded in it

*What it does:* Line-of-sight, viewshed, occlusion, sensor-coverage volumes, terrain
masking, and route deconfliction — analysis, not just display.

*Why it matters:* The current viewport renders geometry but doesn't answer
operationally useful questions like "can this sensor actually see that location" or
"does this route cross a masked area." Keeping this as separate analytical services
(rather than logic embedded in UI code) keeps it independently testable, consistent
with how the rest of this project treats computation vs. rendering.

### 3.3 Assess, Decide & Govern Action

**Safety / Authority Controls for Intercept Planning** — *Critical* — `fusion-policy`
/ `fusion-command`

*What it does:* An authority model, human-approval workflow, geofence/no-go
enforcement, and an explicit decision boundary between "the system recommends" and
"a resource acts" — sitting in front of the Intercept Planning Service's output.

*Why it matters:* The current Intercept Service produces a plan; nothing governs
whether, how, or by whom that plan is authorized before anything happens. In any
deployment where an intercept recommendation has real-world consequences, this is not
an optional add-on — it's the difference between a decision-support tool and an
unsupervised action system, which is a fundamentally different (and much
higher-risk) thing to field without controls.

**Threat / Risk Assessment** — *Medium* — `fusion-assessment`

*What it does:* Formal threat/risk scoring, predicted trajectory and time-to-impact,
asset exposure, and confidence-aware prioritization feeding into the allocation
decision — the missing "why does this track matter more than that one" layer in
front of the DP solver.

*Why it matters:* The allocation service currently optimizes a reward/cost matrix it's
given, but nothing in the current design defines *how* that matrix's values are
actually derived from real threat/priority reasoning — that's a substantial, currently
unaddressed piece of business logic.

**Decision Support Beyond DP Allocation** — *Medium* — `fusion-decision`

*What it does:* Course-of-action generation and comparison, constraint handling
(resource readiness, geometry, policy limits), what-if simulation against a live
snapshot, and explanations for why a given plan was recommended.

*Why it matters:* A single optimization method is a starting point, not a complete
decision-support capability — real operational decisions usually need alternatives,
explainability, and the ability to ask "what if" before committing to a plan, none of
which the current allocation-only design provides.

**Model Lifecycle & Algorithm Governance** — *Medium* — `fusion-modelops`

*What it does:* A registry for selecting, tuning, comparing, validating, promoting,
and rolling back filter/association configurations by mission profile.

*Why it matters:* The tracking core offers multiple filters and association
strategies, but nothing manages *which configuration is in use where*, or governs
changing it safely — an operational gap once more than one mission profile or
deployment site is in play.

### 3.4 Visualize & Interact Safely

**Human Factors & Operator Workflow Design** — *Medium* — role-based workspace
definitions, alert lifecycle, workflow state machines

*What it does:* Defines role-specific workspaces (operator, supervisor, analyst,
sensor manager), alert acknowledgment/escalation, annotation and case workflows, and
usability acceptance criteria — turning a set of panels into a designed operator
workflow.

*Why it matters:* The current UI names panels but doesn't yet define who uses which
view, how an alert gets acknowledged and handed off, or how operator workload is
managed under a high-track-count scenario — all of which matter more as
deployment scale grows.

**Collaboration & Multi-User Concurrency** — *Medium* — a collaboration service +
server-authoritative mission state (if required)

*What it does:* Shared operational picture across multiple simultaneous users,
concurrent edits/annotations, and authority conflict resolution.

*Why it matters:* The application is currently designed around one operator, one
workstation, one `AppState`. This is a scoping question worth resolving explicitly and
early: if multiple simultaneous users are ever required, it has architectural
implications that are far cheaper to design in now than retrofit later.

### 3.5 Secure, Operate & Sustain

**Cybersecurity & Platform Hardening** — *Critical* — `fusion-security`

*What it does:* Authentication, authorization (role/attribute-based), encryption in
transit and at rest, secrets/key management, signed binaries and configuration, an
SBOM, and audit logging for configuration/algorithm/plan changes.

*Why it matters:* Nothing in the current design specifies identity, access control,
or supply-chain assurance at all. For a system that ingests external sensor feeds and
recommends physical-world actions, this is a baseline requirement for any real
deployment, not a later-stage hardening pass.

**System-of-Systems API Boundary** — *High* — `fusion-api`

*What it does:* Versioned REST/gRPC/event-stream interfaces so remote clients,
external command-and-control systems, analytics tools, or enterprise data services
can integrate with this application, plus a compatibility/contract-governance
process for those interfaces over time.

*Why it matters:* The current design is desktop-centric with no defined way for
anything outside the application to consume its output or feed it data
programmatically — a significant limitation for any deployment that isn't a single
standalone workstation.

**Health, Observability & Operational Diagnostics** — *High* — `fusion-observability`

*What it does:* Production-facing metrics, structured logs, distributed traces,
health checks, watchdogs, and alert correlation — extending the existing
developer-facing `tracing` instrumentation into an operator-facing system-status
capability.

*Why it matters:* `tracing` today answers "help a developer debug a specific test
failure." It doesn't yet answer "is this deployed system healthy right now" for
whoever is responsible for keeping it running — a different audience and a different
capability.

**Resilience & Disconnected Operations** — *Medium*

*What it does:* Offline-first behavior, source failover, checkpoint/recovery, and
graceful handling of a lost GPU or dropped sensor feed.

*Why it matters:* Nothing in the current design addresses what happens when a
dependency fails mid-session — whether that's acceptable depends entirely on the
deployment environment, which is exactly why this should be resolved as a
requirement rather than discovered in the field.

**Deployment Topology** — *Medium*

*What it does:* Defines which executable deployment shapes are actually supported —
desktop-only, edge appliance, service node, cloud, hybrid — as distinct profiles built
from the same core libraries.

*Why it matters:* The current architecture describes crates, not deployment units.
Knowing the target deployment shape early materially affects several other
capabilities on this list (collaboration, API boundary, security posture).

**Scalability & Performance Budgets** — *Medium*

*What it does:* End-to-end latency, throughput, memory, GPU, and recovery-time
service-level objectives, derived from realistic mission-scale scenarios rather than
component-level benchmarks alone.

*Why it matters:* The UI has a frame-rate target and the tracker has component
benchmarks, but nothing currently states an end-to-end performance commitment a
deployment could be held to.

**Data Standards & Interoperability** — *Medium*

*What it does:* A controlled schema catalog, version-negotiation policy, and formal
Interface Control Documents for the JSON/Arrow and ASTERIX/STANAG interop already
mentioned in the tracking documents.

*Why it matters:* Interop formats are named as a goal but not yet governed — without
an owned schema catalog and compatibility rules, "we support ASTERIX/STANAG" is not
yet a claim this project could back up in an integration with a third-party system.

**Software Assurance & Release Governance** — *Lower*

*What it does:* Release signing, vulnerability management, license governance,
artifact promotion, and compliance-evidence generation layered onto the existing CI.

*Why it matters:* The differential-oracle/property/concurrency verification stack is
genuinely strong for algorithmic correctness; this adds the parallel assurance track
needed before a release is something an organization could stand behind externally.

### 3.6 Validate Against Reality

**Reporting, After-Action Review & Export** — *Lower* — `fusion-reporting`,
`fusion-replay`

*What it does:* Deterministic session playback, timeline scrubbing, mission reports,
and export packages with provenance preserved.

*Why it matters:* The tracking core's RTS/fixed-lag smoothing already implies
post-hoc analysis is a valued use case; nothing currently packages that analysis into
something a stakeholder outside the engineering team could actually read or act on.

**Expanded Verification (operational, not just algorithmic)** — *Lower*, ongoing

*What it does:* Hardware/sensor-in-the-loop testing, recorded-data replay from real
sources, interface conformance suites, site-acceptance testing, end-to-end load
testing, operator-workflow testing, and security/supply-chain testing — extending the
existing six-gate CI stack rather than replacing it.

*Why it matters:* The current verification matrix is unusually strong for proving the
*math* is correct. It does not yet prove the *system* is operationally ready — those
are different claims, and conflating them risks false confidence that passing CI
means the system is field-ready.

---

## 4. Recommended Build Increments

A practical path that closes the gaps above without disturbing the existing,
already-sound crate boundaries.

**Increment 1 — Productize the core.** Add `fusion-model`, replace ad hoc service
outputs with versioned snapshot/event contracts, add configuration and mission/session
lifecycle, add a local event journal for deterministic replay.
*Business exit criterion:* a user can load a recorded scenario, watch the live
picture, inspect track quality/history, get a recommendation, and replay the whole
session with the same result.

**Increment 2 — Integrate real data.** Add `fusion-ingest`, `fusion-time`, sensor
registry/calibration, source health scoring, durable transport/persistence.
*Business exit criterion:* multiple real or recorded sources enter through governed
adapters, get normalized, and retain traceable provenance all the way to the display.

**Increment 3 — Close the decision-support loop.** Add threat/risk scoring,
constraint/policy engines, what-if execution, operator approval workflows, decision
explanations and audit trails, safe degraded behavior under low confidence.
*Business exit criterion:* the system recommends — never autonomously executes —
policy-constrained actions with a clear rationale and a complete audit trail.

**Increment 4 — Operationalize and scale.** Add deployment topology, collaboration/
shared state (if needed), observability, security, release assurance, and
performance/capacity targets.
*Business exit criterion:* the system supports its actual target deployment profile
with measurable reliability, performance, security, and recoverability.

---

## 5. New Crate Map (Business View)

| Crate | Business capability | Domain | Priority |
|---|---|---|---|
| `fusion-model` | Shared, versioned definitions of a track/detection/plan/resource | Foundational | Critical |
| `fusion-eventing` | "What changed and when," for replay/persistence/collaboration | Foundational | High |
| `fusion-store` | Durable sessions, replay artifacts, audit logs, retention policy | Foundational | High |
| `fusion-config` / `fusion-mission` | Managed sensor/resource/mission configuration | Foundational | High |
| `fusion-ingest` | Real sensor/external-system data entry, validated | Sense/Ingest | Critical |
| `fusion-sensor-management` | Sensor registry, tasking, calibration, coverage | Sense/Ingest | High |
| `fusion-time` | Clock discipline, source vs. receipt time, replay-time control | Sense/Ingest | Critical |
| `fusion-identity` | Persistent global track identity, lineage, merge/split | Understand | High |
| `fusion-identification` | Friend/foe/unknown classification | Understand | Medium |
| `fusion-geo` | Map/imagery layers, CRS governance, geofencing | Understand | Medium |
| `fusion-policy` / `fusion-command` | Authority, approval workflow, no-go enforcement | Assess/Decide | Critical |
| `fusion-assessment` | Threat/risk scoring, predicted impact | Assess/Decide | Medium |
| `fusion-decision` | Course-of-action generation, what-if analysis | Assess/Decide | Medium |
| `fusion-modelops` | Algorithm/config selection, validation, rollback | Assess/Decide | Medium |
| `fusion-security` | AuthN/AuthZ, encryption, secrets, signed releases, audit | Secure/Operate | Critical |
| `fusion-api` | External/remote integration surface | Secure/Operate | High |
| `fusion-observability` | Operator-facing system health, alert correlation | Secure/Operate | High |
| `fusion-replay` / `fusion-reporting` | Deterministic playback, mission reports, export | Validate | Lower |

---

## 6. Principal Risks If These Gaps Aren't Addressed

**The current service contracts are too thin to build on top of long-term.**
`submit_detection`, `tracks`, and `plan` communicate the right conceptual boundary,
but omit lifecycle, errors, quality, security context, and provenance. Building
ingestion adapters or a UI tightly against today's minimal contract risks rework once
the fuller contract (canonical model, event-based snapshots) arrives — worth
resolving before more is built on top of the current sketch.

**`AppState` must not become the system of record.** The single-source-of-truth rule
is correct for a desktop app's *rendering* state, but if it's also treated as the
durable, authoritative record of all tracks, plans, and operator actions, then
persistence, multi-user support, and replay all become expensive retrofits rather
than natural extensions. `AppState` should end up as a local projection of durable
mission state, not the mission state itself.

**The two "fusion" pipelines can coexist visually while staying statistically
disconnected.** GPU point-cloud registration and the tracking core's sensor
registration/bias estimation are correctly kept as separate crates, but nothing
currently passes registration output (estimated transform, uncertainty, calibration
version) into the tracking side as evidence. Without that connection, the 3D view
could show a well-aligned point cloud while the tracker's own bias model knows
nothing about it — a plausible-looking but analytically untrustworthy combined
picture.

**Verification proves algorithm correctness, not operational readiness.** The
existing six-gate CI stack is genuinely strong evidence that the *math* is right.
It is not evidence that the *system* is ready to field — interface conformance,
security testing, replay/persistence integrity, and operator-workflow testing are a
different, currently uncovered claim. Treating "CI is green" as "ready to deploy"
would be a false-confidence risk worth flagging explicitly to stakeholders.

---

## How to read this alongside the other documents

- **`capability-descriptions.md`** remains authoritative for the original tracking/
  estimation/allocation capabilities — untouched by this document.
- **`ARCHITECTURE.md`** (fusion workspace) is the technical reference for how the
  crates already built map to the capabilities in Section 1.
- **`verification-capability-table.md`** and `scenario-crate-narrative.md` remain the
  source of truth for the tracking core's pass/fail criteria — the gaps in Section 3
  don't yet have equivalent verification rows and would need them before being
  considered "done" in the same sense as that table's existing rows.
- This document is expected to change as scoping decisions get made — several items
  above (multi-user support, deployment topology, real-time action vs.
  recommendation-only) are flagged specifically because they're requirements
  questions, not just engineering tasks, and the right next step for those is a
  scoping conversation, not code.
