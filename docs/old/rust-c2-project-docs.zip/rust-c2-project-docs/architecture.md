# Architecture

Workspace layout and how each crate maps to `verification-capability-table.md`
and `scenario-crate-narrative.md`. See those two documents for verification
method, pass criteria, and data source per capability.

| Crate | Table module | Notes |
|---|---|---|
| `gungnir-core` | `core` | CV/CA/CT — exact-match closed-form checks only |
| `gungnir-filters` | `filters` | KF/EKF/UKF/PF/IMM/sqrt-UDU/RTS |
| `gungnir-association` | `association` | NN/GNN, Hungarian/JV, gating, JPDA, MHT |
| `gungnir-track` | `track-manager` | lifecycle |
| `gungnir-rfs` | `rfs` (new) | PHD/CPHD, GLMB/LMB |
| `gungnir-fusion-async` | `fusion-async` | OOS/multi-rate + concurrency |
| `gungnir-track-fusion` | `track-fusion` (new) | CI/info-matrix fusion, registration/bias |
| `gungnir-coord` | `coord` (new) | ECEF/ENU/NED/geodetic |
| `gungnir-allocation` | `allocation` | Bellman/DP |
| `gungnir-scenario` | `scenario` (new) | five-scenario generator |
| `gungnir-metrics` | `metrics` (new) | MOTA/MOTP, purity/fragmentation |
| `gungnir-oracle` | *(cross-cutting)* | differential-test harness, CI gate #1 |
| `gungnir-testkit` | *(cross-cutting)* | shared proptest invariants, CI gate #2 |
| `gungnir-fuzz` | *(cross-cutting)* | fuzz targets, CI gate #5 |
