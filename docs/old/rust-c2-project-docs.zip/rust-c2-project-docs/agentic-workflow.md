# Agentic development workflow

This document describes how AI coding agents are used in the `gungnir`
codebase, what they are trusted to do unsupervised, and what verification
gates stand between agent-written code and `main`. It exists so a reviewer
or adopter can see the guardrails directly rather than take correctness on
faith.

## Risk triage: where agents fit

**High-leverage, low-risk — agents may work with light review:**
- Scaffolding trait boilerplate across motion models (CV, CA, CT) once the
  core `State`/`Measurement` traits are human-designed
- Property-based test and edge-case generation for association/assignment
  algorithms
- Differential-test harness plumbing (`gungnir-oracle`) against reference
  implementations (`filterpy`/`motpy`, textbook closed-form solutions)
- Docs, examples, and tutorials
- Dependency upgrades, clippy/lint cleanup, benchmark-report generation
- The async simulation harness (fake sensor streams at different rates) —
  mostly plumbing, not correctness-critical

**Medium-risk — agent-assisted, mandatory verification gate before merge:**
- Kalman/EKF/UKF math and the assignment algorithms (Hungarian/JV, JPDA)
- The Bellman/DP resource-allocation solver (`gungnir-allocation`)

**Low-trust — human-owned, agents may draft but not merge unsupervised:**
- Any `unsafe` block, anywhere in the workspace
- Concurrency correctness in `gungnir-fusion-async` (lock-free structures,
  channel backpressure, out-of-order measurement handling)
- Numerical stability guarantees (covariance must stay positive
  semi-definite; no silent NaN propagation)

## The verification stack

"Tests pass" is not sufficient for numerics/real-time code — an agent can
write plausible-looking filter code that is subtly wrong (e.g. the wrong
Joseph-form covariance update). Gates are structural:

1. **Differential testing against a trusted oracle** (`gungnir-oracle`,
   `.github/workflows/oracle-diff.yml`) — same scenario through a
   hand-verified reference, numerical agreement asserted within the
   tolerance in `verification-capability-table.md`.
2. **Property-based invariant testing** (`gungnir-testkit`, `proptest`) —
   e.g. posterior covariance stays PSD, track IDs are never reused while
   active, assignment solutions respect the constraint matrix. Agents
   write the test given an invariant; a human authors the invariant.
3. **`cargo miri`** (`.github/workflows/miri.yml`) on any PR touching
   `unsafe`.
4. **`loom`** (`.github/workflows/loom.yml`) on `gungnir-fusion-async` —
   exhaustive interleaving, run against the real scenario-3 async
   pipeline rather than a synthetic stress harness.
5. **Fuzzing** (`gungnir-fuzz`, `.github/workflows/fuzz-nightly.yml`) on
   the sensor-ingestion parser and association cost-matrix construction.
6. **Benchmark regression gate** (`.github/workflows/bench-regression.yml`)
   — `criterion` vs. baseline, hard-fail beyond a p99 latency threshold.

## Review pipeline

- **Implementer agent** — writes the change against a human-authored spec.
- **Reviewer agent** — separate pass, fixed checklist (numerical stability,
  error handling, test coverage, doc comments, no unexplained `unwrap()`),
  explicitly prompted to be adversarial rather than confirmatory.
- **Verifier gate** — the six checks above. Non-negotiable; cannot be
  waived by either agent.
- **Human sign-off** — required for anything touching `unsafe`,
  concurrency, or the numerical core. The PR must cite *why* an approach
  was used (e.g. "Joseph form used here instead of the simpler update
  because it's numerically stable under repeated updates — see
  Bar-Shalom §5.3"), not just that it passes.

See `CONTRIBUTING.md` for how this applies to a specific PR.
