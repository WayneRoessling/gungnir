# Gungnir Capability Descriptions

Business-analyst reference companion to `verification-capability-table.md`, `scenario-crate-narrative.md`, and `gungnir-workspace-structure.md`. Each entry below expands one row of the verification table into a stakeholder-readable capability description: what it does, why it matters to the business, how it is proven correct, what "done" looks like, and what happens if it's wrong.

Capabilities are grouped by owning module, in the same order as the verification table.

---

## `core` — Motion Models

### Motion Models: CV, CA, CT

**What it does:** Provides the constant-velocity, constant-acceleration, and coordinated-turn kinematic models that describe how a tracked object is expected to move between sensor updates. These models generate the state-transition (`F`) and process-noise (`Q`) matrices every downstream filter depends on.

**Why it matters:** This is the mathematical foundation of the entire tracking stack — every filter, smoother, and fusion algorithm in the product ultimately predicts an object's next position using one of these three models. An error here doesn't stay contained; it silently propagates into every capability built on top of it.

**How it's verified:** Element-wise comparison of the generated `F`/`Q` matrices against `filterpy.kalman` and hand-derived references in Python, and against MATLAB's `initcvkf`/`initcakf`/`initctekf` functions, for the same initial state and time step.

**Definition of done:** Matrix elements match to within ~1e-10 — effectively exact, since this is a closed-form calculation with a single correct answer.

**Data used:** Synthetic fixtures only. Real-world trajectory data adds nothing here because the check is deterministic math, not behavior — a scenario-crate-generated dataset would only add noise to a check that should be exact.

**Risk if wrong:** A broken Jacobian or transition matrix here would masquerade as a filter bug, association bug, or fusion bug several layers downstream, and could go undetected until scenario-based testing much later in the pipeline — which is why this is validated first, before anything else.

---

## `filters` — State Estimation

### Linear Kalman Filter

**What it does:** Implements the standard (linear) Kalman filter — the baseline recursive estimator for tracking a single object under linear motion and measurement assumptions.

**Why it matters:** This is the reference implementation every more sophisticated filter (EKF, UKF, IMM) is ultimately compared against or built out from. It's also the cheapest, fastest filter in the product, and the correct default when linearity assumptions actually hold.

**How it's verified:** Run the same measurement sequence through the Rust implementation, `filterpy.kalman.KalmanFilter`, and MATLAB's `trackingKF`; compare the full state and covariance trajectory, not just the final value.

**Definition of done:** State trajectory error under 1e-6; covariance matrix Frobenius-norm difference under 1e-6.

**Data used:** Synthetic fixture — a controlled, linear measurement sequence with a known correct answer.

**Risk if wrong:** Since every other filter either extends or is validated against this baseline, an undetected error here undermines confidence in the entire filter suite.

### Extended Kalman Filter (EKF)

**What it does:** Extends the Kalman filter to nonlinear measurement models (e.g., radar returning range/bearing/elevation against a Cartesian state) by linearizing around the current estimate using the Jacobian.

**Why it matters:** Most real sensors (radar, sonar, camera) are nonlinear, so this is the workhorse filter for realistic single-target tracking — it's what the product will actually run in production far more often than the plain linear KF.

**How it's verified:** Same nonlinear scenario and Jacobians run through the Rust EKF, `filterpy.kalman.ExtendedKalmanFilter`, and MATLAB's `trackingEKF`; trajectories compared.

**Definition of done:** Relative error under 1e-4.

**Data used:** Scenario-crate generated — specifically the single-maneuvering-aircraft scenario, chosen because its nonlinearity is real but not adversarial, so a failure here indicates a math error rather than a degenerate test setup.

**Risk if wrong:** Since the EKF is the most commonly deployed filter, an undetected error has the broadest real-world blast radius of any single filter bug.

### Unscented Kalman Filter (UKF)

**What it does:** An alternative to the EKF for nonlinear systems that avoids explicit Jacobian computation by propagating a small set of deterministically chosen sigma points through the nonlinear model.

**Why it matters:** UKF is more robust than EKF for cases with strong nonlinearity or where Jacobians are expensive or error-prone to derive, giving the product a second nonlinear-filtering option with different failure characteristics.

**How it's verified:** Same sigma-point parameters run through the Rust UKF, `filterpy.kalman.UnscentedKalmanFilter`, and MATLAB's `trackingUKF`; state and covariance compared.

**Definition of done:** Relative error under 1e-4, and sigma-point weights must sum to exactly 1 (a structural correctness check independent of accuracy).

**Data used:** Scenario-crate generated (same maneuvering-aircraft scenario as EKF, so both filters are held to the same test conditions).

**Risk if wrong:** A subtle sigma-point weighting error could produce plausible-looking but biased estimates that only surface as accumulated drift over time, rather than an obvious single-step failure.

### Particle Filter

**What it does:** A sequential Monte Carlo estimator that represents the target's belief state as a weighted set of samples ("particles") rather than a Gaussian, allowing it to track genuinely non-Gaussian, multimodal distributions.

**Why it matters:** This is the fallback for situations where the EKF/UKF's Gaussian assumption breaks down — for example, ambiguous bearings-only tracking where multiple hypotheses about an object's position are simultaneously plausible. Without it, the product has no answer for that class of problem.

**How it's verified:** Because there's no single "correct" trajectory to match exactly, verification is statistical: run many trials and compare the resulting distribution to `filterpy.monte_carlo`/a custom SIR implementation via a KS-test or mean/variance comparison. There is no MATLAB oracle for this row.

**Definition of done:** KS-test passes, or mean and variance fall within 2σ of the reference distribution.

**Data used:** Scenario-crate generated, specifically the dense-swarm scenario's bearings-only/narrow-FOV sub-case — deliberately engineered to produce a genuinely multimodal posterior, because on an easy, well-conditioned target set the particle filter would just be a slower, noisier way of getting the same answer EKF/UKF already give, and the test would not be discriminating.

**Risk if wrong:** Particle degeneracy or weight collapse is a classic silent failure mode — the filter can look like it's working (producing an estimate) while having effectively lost track of the true multimodal belief.

### Interacting Multiple Model (IMM)

**What it does:** Runs several motion models (e.g., CV and CT) in parallel and blends their estimates using mode probabilities, so the tracker can represent both "flying straight" and "turning" behavior without committing to one model in advance, and switch between them as evidence accumulates.

**Why it matters:** Real targets — aircraft, vehicles, vessels — maneuver. A tracker that only knows one motion model either lags badly during turns or is tuned so loosely that it's noisy in straight-line flight. IMM is the product's answer to "track objects that behave like real objects."

**How it's verified:** Same model set and mode-transition matrix run through the Rust IMM, Stone Soup's `IMM`, and MATLAB's `trackingIMM`; both the mixed state estimate and the mode probabilities are compared.

**Definition of done:** State error under 1e-4; mode probabilities within 1e-3.

**Data used:** Scenario-crate generated — specifically the maneuvering-aircraft scenario's CV→CT transition, because a trajectory that never actually maneuvers never forces the mode probabilities to move, making the pass criterion untestable. Supplemented with real ADS-B/OpenSky flight tracks as an independent real-world reference for mode-switch behavior, since simulated maneuvers can be tuned to be easier than reality.

**Risk if wrong:** Slow or incorrect mode-probability convergence means the tracker effectively "waits too long" to recognize a target has started turning, producing a lagging track exactly when maneuver-tracking matters most.

### Square-root / UDU-Factorized KF & EKF

**What it does:** A numerically hardened reformulation of the (extended) Kalman filter that propagates the covariance in square-root or UDU-factorized form instead of directly, guaranteeing the covariance matrix stays positive-semidefinite (PSD) even under numerical stress that would break a standard-form filter.

**Why it matters:** Standard-form covariance can drift non-PSD after many cycles or under ill-conditioned geometry, silently corrupting every downstream estimate. This variant exists specifically as an insurance policy for long-running or numerically stressed deployments where that failure mode would otherwise be invisible until it's already caused bad tracks.

**How it's verified:** Two-part check — first, standard functional comparison against the equivalent standard-form filter (there is no MATLAB oracle exposed for this internal toolbox capability); second, a dedicated soak test asserting PSD covariance every cycle over an extended run.

**Definition of done:** Under 1e-6 difference vs. the standard-form filter; zero PSD violations over 10⁵+ cycles.

**Data used:** Synthetic fixture for the functional comparison; scenario-crate generated (adversarial geometry / soak scenario) for the stability test — the entire point of this capability is only exercised by deliberately near-singular geometry, which realistic scenarios avoid by construction.

**Risk if wrong:** This is the capability specifically meant to prevent the worst-case numerical failure mode in the product; an undetected bug here defeats the purpose of having a hardened filter at all.

### RTS Smoother / Fixed-Lag Smoothing

**What it does:** A backward pass over an already-filtered trajectory (Rauch-Tung-Striebel smoothing) that uses future information to improve past state estimates, producing a smoother, more accurate trajectory than the forward-only filter alone.

**Why it matters:** Forward filtering is inherently causal — it can't use information it hasn't seen yet. For post-hoc analysis (accident reconstruction, track review, offline reporting) smoothing gives a materially better estimate of where a target actually was.

**How it's verified:** Run a forward filter pass followed by the smoother pass; compare the smoothed trajectory against `filterpy.kalman.rts_smoother`. There is no canonical MATLAB reference for this row.

**Definition of done:** Relative error under 1e-6.

**Data used:** Scenario-crate generated, specifically the long-duration adversarial/soak scenario — a short trajectory can confirm the smoother's math is correct but only a long, coherent run can reveal whether the smoothed estimate stays coherent or accumulates error over time. Supplemented with ADS-B/OpenSky tracks, with the caveat that in that case "truth" is itself a smoothed reference rather than independently known ground truth.

**Risk if wrong:** Because smoothing is typically used for downstream reporting and post-incident analysis, an error here could produce confidently wrong "official" reconstructions of what happened, with no forward-pass safety net to catch it.

---

## `association` — Measurement-to-Track Association

### Nearest-Neighbor / GNN

**What it does:** Assigns each sensor detection to the single most likely existing track using a global nearest-neighbor cost minimization.

**Why it matters:** This is the simplest, cheapest association strategy and the default choice whenever ambiguity between targets is low — most of the time, in most deployments, this is the algorithm actually doing the work.

**How it's verified:** Same cost matrix run through the Rust implementation and a custom `scipy.linear_sum_assignment`-backed reference in Python, and MATLAB's `trackerGNN`/`assignauction`; assignment pairs compared directly.

**Definition of done:** Exact match.

**Data used:** Synthetic fixture — a hand-constructed cost matrix, since this is a deterministic optimization problem with one correct answer.

**Risk if wrong:** As the default association strategy, an off-by-one or tie-breaking bug here would misassign detections in the common case, not just the edge case.

### Hungarian / Jonker-Volgenant

**What it does:** The optimal assignment algorithm underlying GNN association, solving the cost-minimizing bipartite matching between detections and tracks, including degenerate and non-square (rectangular) cost matrices.

**Why it matters:** This is the combinatorial-optimization engine that GNN, and indirectly other association strategies, rely on to actually solve the assignment problem correctly and efficiently.

**How it's verified:** Same cost matrix, including degenerate/rectangular cases, run through the Rust solver, `scipy.optimize.linear_sum_assignment`, and MATLAB's `assignjv`; total cost and assignment compared.

**Definition of done:** Exact match on total cost; assignment itself only required to match when the solution isn't tied (multiple equally optimal assignments are acceptable).

**Data used:** Synthetic fixture, deliberately including degenerate and rectangular matrices to exercise edge cases a "normal" cost matrix wouldn't hit.

**Risk if wrong:** A solver bug here corrupts every algorithm built on top of it (GNN today, potentially others later), and rectangular/degenerate-matrix bugs are exactly the kind that pass casual testing and fail in production.

### Gating (Ellipsoidal / Chi-Square)

**What it does:** Filters out detections that are statistically implausible given a track's predicted position and uncertainty, before they're even considered for association — reducing both computational cost and the risk of assigning a clearly-wrong detection to a track.

**Why it matters:** Gating is the first line of defense against clutter and noise; every association algorithm downstream (GNN, JPDA, MHT) depends on gating having correctly narrowed the candidate set.

**How it's verified:** Same predicted state/covariance and measurement set run through the Rust gate, a custom closed-form chi-square implementation, and MATLAB's internal `trackingEKF`/`trackingGNN` distance function; gate membership (in/out) compared.

**Definition of done:** Exact match.

**Data used:** Synthetic fixture.

**Risk if wrong:** A gate that's too loose lets clutter into the association step (corrupting JPDA/MHT results downstream); a gate that's too tight silently drops legitimate detections, causing missed tracks.

### JPDA

**What it does:** Joint Probabilistic Data Association — computes probability-weighted associations between multiple tracks and multiple ambiguous detections simultaneously, rather than committing to a single hard assignment, so tracks are updated with a probability-weighted blend of plausible detections.

**Why it matters:** This is what the product needs once clutter density or target proximity is high enough that greedy nearest-neighbor starts making outright wrong assignments — the difference between a tracker that degrades gracefully in clutter and one that doesn't.

**How it's verified:** Per-track association probabilities compared against Stone Soup's `JPDA` hypothesiser and MATLAB's `trackerJPDA`, on a shared clutter scenario.

**Definition of done:** Relative error under 1e-3.

**Data used:** Scenario-crate generated (maritime clutter scenario, tuned to a harder operating point than the base association tests, using the *same* underlying sensor and clutter model — so JPDA validation doesn't depend on trusting a second, independently-unverified clutter model). Supplemented with Stone Soup's own example JPDA scenario files, which is valuable specifically because Stone Soup is also the oracle here, reducing the risk of oracle/dataset mismatch.

**Risk if wrong:** Incorrect probability weighting under ambiguity is the kind of bug that only shows up statistically over many scenarios, not in a single obvious failure — making it easy to ship undetected.

### Multi-Hypothesis Tracking (MHT)

**What it does:** Maintains multiple competing hypotheses about track-to-detection association over time, deferring hard decisions until enough evidence accumulates to prune unlikely branches — the most sophisticated association strategy in the product.

**Why it matters:** In the highest-clutter, highest-ambiguity environments, even JPDA's single-time-step probabilistic blending isn't enough; MHT is the capability that lets the product hold open multiple plausible explanations of the scene across time and resolve them as new data arrives.

**How it's verified:** Compare hypothesis tree structure and top-N hypothesis scores against Stone Soup's MHT hypothesiser and MATLAB's `trackerTOMHT`.

**Definition of done:** Relative error under 1e-3 on scores; tree structure must match at each pruning step (not just the final result).

**Data used:** Scenario-crate generated — the same maritime clutter scenario as JPDA, at a harder operating point, so MHT and JPDA are validated against a consistent, shared ambiguity model.

**Risk if wrong:** Because MHT reasons over a tree of hypotheses across time, a pruning-step error compounds — an incorrect early prune can silently eliminate the branch that would have become the correct track.

---

## `track-manager` — Track Lifecycle

### Track Lifecycle (Init / Confirm / Coast / Delete)

**What it does:** Governs the state machine that decides when a sequence of detections becomes a confirmed track, when a track that's stopped receiving detections should be "coasted" (kept alive on prediction alone) rather than deleted, and when it should finally be dropped.

**Why it matters:** This is what determines whether the product reports a real, sustained track to an operator versus noise, and whether a track survives a brief sensor dropout (e.g., a vessel passing behind a landmass) instead of being incorrectly terminated and re-initiated as a "new" object.

**How it's verified:** Run an identical detection/miss sequence through the Rust track manager, Stone Soup's track initiators/deleters, and MATLAB's `trackHistoryLogic`/`trackScoreLogic`; compare the exact step index at which confirm/delete transitions occur.

**Definition of done:** Exact match on step index.

**Data used:** Scenario-crate generated — specifically the maritime clutter scenario's land-mask dropout, which is what gives "coast" logic something real to do; without an actual missed-detection run, "coast" is a code path that's never genuinely exercised.

**Risk if wrong:** A coast/delete threshold error either drops real tracks prematurely (operationally worse than it sounds, since the target then re-appears as a "new" unconfirmed track, losing history) or keeps stale tracks alive too long, cluttering the operator picture.

---

## `rfs` — Random Finite Set Filters

### PHD / CPHD Filter

**What it does:** Probability Hypothesis Density / Cardinalized PHD — a random-finite-set filter that tracks the *number* of targets and their collective intensity function directly, rather than maintaining individual track identities, making it well suited to dense, unlabeled target fields.

**Why it matters:** Traditional track-per-object approaches degrade in dense scenes where target count is itself uncertain (birth/death, closely-spaced objects). PHD/CPHD is the product's answer for scenarios where "how many objects are there" is as important a question as "where are they."

**How it's verified:** Same birth/clutter/detection model run through the Rust implementation, Stone Soup's GM-PHD/GM-CPHD, and MATLAB's `trackerPHD`; both the intensity function and cardinality estimate are compared.

**Definition of done:** Weights within 1e-3; exact cardinality match where the answer is unambiguous.

**Data used:** Scenario-crate generated — the dense-swarm scenario, chosen because cardinality estimation is only meaningfully tested with tens to hundreds of closely-spaced targets; a handful of well-separated targets lets a naive approach get the count right by accident. Supplemented by Stone Soup's example PHD/CPHD scenarios, and by DARPA/ONR RFS challenge or Vo et al. paper-companion data where the specific GM-PHD variant being implemented has published scenario files — chosen because oracle and dataset come from the same source, minimizing mismatch risk.

**Risk if wrong:** A cardinality-estimation error is a distinctly business-visible failure mode — it means the product is reporting the wrong *number* of objects present, not just imprecise positions.

### GLMB / LMB Filter

**What it does:** Generalized Labeled Multi-Bernoulli / Labeled Multi-Bernoulli — a random-finite-set filter, like PHD/CPHD, but one that additionally maintains persistent target *identity* (labels) alongside cardinality, so individual objects can be tracked as distinct entities even in dense scenes.

**Why it matters:** PHD/CPHD answers "how many"; GLMB/LMB answers "how many, and which one is which, over time" — critical when downstream consumers need to reason about individual object trajectories in a dense field, not just aggregate counts.

**How it's verified:** Same scenario run through the Rust implementation, Stone Soup's (partial) GLMB implementation, and MATLAB's `trackerGLMB`; label-to-track assignment and existence probabilities compared.

**Definition of done:** Existence probability within 1e-3; label continuity must match (an object's identity label must persist correctly across the run).

**Data used:** Scenario-crate generated (same dense-swarm scenario as PHD/CPHD, for a shared, trusted ambiguity baseline). Supplemented with Vo et al. / RFS-toolbox companion scenario files where available, for the same same-source oracle/dataset rationale as PHD/CPHD.

**Risk if wrong:** A label-continuity bug specifically produces "identity switching" — the product reporting that object A became object B mid-track — which is often more operationally damaging than a small positional error, since it corrupts any downstream history or behavior analysis tied to that identity.

---

## `fusion-async` — Asynchronous Multi-Sensor Fusion

### Out-of-Sequence Handling / Multi-Rate Fusion

**What it does:** Correctly incorporates detections that arrive late or out of chronological order, and reconciles sensors that report at different, uncoordinated rates (e.g., a slow camera, a faster radar, a lidar with its own latency), so the fused track reflects the true timeline of events rather than the order data happened to arrive.

**Why it matters:** Any deployment with more than one sensor type will encounter this in normal operation, not as an edge case — sensors simply don't share a clock or a cadence. Getting this wrong means fused tracks are built on a scrambled timeline.

**How it's verified:** Replay a fixed multi-sensor timeline through the async pipeline and compare the result against an offline batch computation of the same timeline, using Stone Soup's (thin) OOS updater as a partial reference. There is no direct MATLAB equivalent for this row.

**Definition of done:** State convergence within 1e-4; latency itself is not part of the pass/fail criterion (it's a correctness check, not a performance check).

**Data used:** A recorded/synthetic fixed multi-sensor timeline — specifically, the urban multi-sensor convoy scenario, which exists in this test plan *specifically* to manufacture genuine sensor timing disagreement (deliberately mismatched rates and out-of-order arrivals), because a single artificially delayed message in an otherwise clean stream doesn't exercise the real code path.

**Risk if wrong:** An out-of-sequence handling bug is easy to under-test with a synthetic single-delay case and still fail in production, where the disagreement pattern between real sensors is more complex than any single inserted-delay test would suggest.

### Concurrency Correctness

**What it does:** Verifies that the async fusion pipeline is free of data races and interleaving bugs under Rust's concurrency model, using `loom`'s exhaustive interleaving exploration rather than hoping normal testing happens to hit the bad case.

**Why it matters:** Concurrency bugs are notoriously non-deterministic and hard to reproduce through ordinary testing; they can pass thousands of normal test runs and then fail unpredictably in production under a specific timing pattern. This capability exists to catch that category of bug before it ships.

**How it's verified:** `loom` exhaustive interleaving check, run against the urban convoy scenario's actual pipeline rather than a synthetic stress harness — deliberately, because a race that only appears when the out-of-sequence buffer and the multi-rate scheduler interact under a specific timing pattern would not necessarily be caught by an artificial harness that doesn't reproduce that interaction.

**Definition of done:** Zero races detected.

**Data used:** N/A — this is a code-path exploration technique, not a data-driven comparison.

**Risk if wrong:** This is one of two capabilities in the whole system flagged as requiring mandatory human sign-off in addition to a green CI check (the other being any `unsafe` code block) — reflecting that an undetected concurrency bug can cause silent data corruption in production that's extremely difficult to diagnose after the fact.

---

## `track-fusion` — Multi-Sensor Track Fusion

### Track-to-Track Fusion (CI, Information-Matrix)

**What it does:** Combines multiple independent local tracks of the same real-world object — for example, two sensor platforms each independently tracking the same convoy vehicle — into a single, more accurate global track estimate, using covariance intersection (CI) or information-matrix fusion techniques.

**Why it matters:** This is what lets a multi-sensor deployment produce one coherent picture of the world instead of several conflicting per-sensor pictures — directly relevant to any scenario with overlapping sensor coverage, which is the normal case for any deployment with more than one platform.

**How it's verified:** Feed identical local tracks into the Rust fusion implementation, Stone Soup's (partial) fuser plus a hand-derived CI reference, and MATLAB's `trackFuser`; compare fused state and covariance.

**Definition of done:** State error under 1e-6; covariance Frobenius-norm difference under 1e-6.

**Data used:** Synthetic fixture.

**Risk if wrong:** A fusion bug can make a multi-sensor system perform *worse* than a single sensor alone — for instance, over-confidently combining two tracks in a way that understates the true uncertainty of the fused estimate.

### Sensor Registration / Bias Estimation

**What it does:** Estimates and corrects for unknown systematic position/orientation bias between sensor platforms, so that fusing tracks from misaligned sensors doesn't introduce a persistent offset into the fused result.

**Why it matters:** Real sensor platforms are never perfectly registered to a common reference frame; without bias correction, track-to-track fusion would confidently combine two tracks that are each individually accurate but systematically offset from each other, degrading rather than improving the fused estimate.

**How it's verified:** Inject a known bias by construction and confirm the algorithm recovers it, comparing the Rust implementation against a hand-derived least-squares reference and MATLAB's registration functions.

**Definition of done:** Recovered bias within 1e-3 of the injected ground truth.

**Data used:** Synthetic fixture with bias injected by construction — though in practice this reuses the same urban convoy scenario data that's already producing multi-sensor tracks for the fusion test above, so the registration check is a different read of data the fusion test already needed, not a separate fixture.

**Risk if wrong:** An unrecovered bias doesn't cause an obvious failure — it causes a subtly, persistently wrong fused track that looks plausible, which is a worse operational outcome than a track that's obviously broken.

---

## `coord` — Coordinate Frame Transforms

### Coordinate Frame Transforms (ECEF/ENU/NED/Geodetic)

**What it does:** Converts positions between Earth-Centered-Earth-Fixed, East-North-Up, North-East-Down, and geodetic (lat/lon/altitude) coordinate frames — the foundational geometry every sensor measurement and fused track ultimately has to be expressed in consistently.

**Why it matters:** Coordinate transform bugs are a historically common source of tracking-library failures, specifically at antimeridian crossings (the 180°/-180° longitude wraparound) and near the poles (where the geodetic-to-ECEF mapping becomes singular) — edge cases that are easy to miss because normal operational data rarely visits them.

**How it's verified:** Round-trip transform (convert and convert back) plus cross-library comparison against `pymap3d` in Python and `ecef2enu`/`geodetic2ecef` in MATLAB, on a coordinate grid.

**Definition of done:** Position error under 1e-6 meters (or 1e-9 radians for angular quantities).

**Data used:** Synthetic fixture, deliberately including pole and antimeridian edge cases — the adversarial-geometry scenario exists specifically because no amount of realistic maritime or aircraft data will reliably visit these coordinates unless the test deliberately routes a target through them.

**Risk if wrong:** Because this sits underneath every other capability in the system, a coordinate transform bug could masquerade as a filter, association, or fusion bug in every other test, which is exactly why this is deliberately stress-tested with its own dedicated adversarial scenario rather than relying on incidental coverage.

---

## `allocation` — Resource Assignment

### Bellman/DP Resource-to-Track Assignment

**What it does:** Solves the resource-to-track assignment problem (e.g., which sensor should be tasked to which track) as a dynamic-programming optimization over a reward/cost structure and planning horizon, using a Bellman-equation formulation.

**Why it matters:** In any deployment with more sensors/resources than can be dedicated to every track simultaneously, this is what decides where to point limited resources for maximum tracking value — a scheduling/optimization decision with direct operational cost implications.

**How it's verified:** Same reward/cost matrix and planning horizon run through the Rust DP implementation, a textbook-verified custom Python DP, and (if used) an equivalent MATLAB DP; the resulting policy and value function are compared.

**Definition of done:** Exact match on the value function (1e-9).

**Data used:** Synthetic fixture — a deterministic optimization problem with one correct answer, the same rationale as the `core` motion-model row.

**Risk if wrong:** A DP bug here doesn't produce an obviously "wrong" track — it produces a policy that's subtly suboptimal, silently wasting sensor resources that could have been better allocated.

---

## `scenario` — Ground-Truth & Sensor Simulation

### Ground-Truth & Sensor Simulation (Statistical Self-Check)

**What it does:** Generates synthetic ground-truth trajectories and simulated sensor detections — including configurable detection probability (Pd) and clutter/false-alarm rate — that serve as the input data for roughly half of all other capabilities in this table. This particular row validates that the generator itself produces statistically sound output.

**Why it matters:** Every scenario-crate-generated test elsewhere in this table implicitly trusts that the generator's Pd and clutter rate are actually what they claim to be configured as. If the generator itself is subtly biased, every test built on top of it inherits that bias silently.

**How it's verified:** Statistical comparison of empirical detection/clutter rates over many trials against the configured parameters, using Stone Soup simulators and MATLAB's `trackingScenario`/`objectDetectionGenerator` as reference implementations of the same class of simulation.

**Definition of done:** Empirical rates within 2σ of the configured Pd/clutter rate.

**Data used:** Self-generated — this is a statistical validation of the generator against its own configuration, not against an external dataset. In practice this check rides along "for free" as a side effect of the maritime clutter scenario, since that's the first scenario where Pd and clutter rate are actually being configured to non-default values rather than left at defaults.

**Risk if wrong:** This is arguably the highest-leverage single row in the table — a biased generator doesn't just fail its own test, it silently invalidates the JPDA, MHT, PHD/CPHD, GLMB/LMB, and other results that depend on trusting its output, without any of those downstream tests necessarily showing an obvious failure.

### Round-Trip Fidelity (Generate → Export → Replay)

**What it does:** Verifies that a synthetic scenario generated in-memory can be exported to a recorded data format, replayed back through the `ReplayAdapter`, and reconstructed identically to the original in-memory stream — a self-contained check of the export/import code path.

**Why it matters:** Any workflow that records a scenario for later replay (regression testing, sharing test cases, offline analysis) depends on this round trip being lossless; a silent corruption here would make "replay this failing scenario" an unreliable debugging tool.

**How it's verified:** Generate a synthetic timeline in memory, export it, replay it via `ReplayAdapter`, and compare against the original in-memory stream. There is no external oracle for this row — Python and MATLAB columns are both self-referential, since this is purely a property of the export/import code, not a modeling question.

**Definition of done:** Exact match on measurement content and arrival order; timing must match within the export format's own precision limits.

**Data used:** Self-generated — and deliberately not tied to any of the five narrative scenarios, since round-trip fidelity is a property of the export/import mechanism that would pass or fail identically on even a trivial single-target scenario. Using a more complex scenario here would add nothing.

**Risk if wrong:** A round-trip bug specifically undermines trust in recorded test cases and regression fixtures — if replay doesn't faithfully reproduce what was recorded, "this bug reproduces in the replay" claims become unreliable.

---

## `metrics` — Tracking Performance Metrics

### MOTA/MOTP, Purity/Fragmentation, Track-to-Truth Assignment

**What it does:** Computes standard multi-object-tracking accuracy metrics — MOTA (accuracy, penalizing misses/false positives/identity switches), MOTP (precision of correctly matched tracks), purity, and fragmentation — by first assigning tracker output to ground truth and then scoring the result.

**Why it matters:** These are the industry-standard metrics used to communicate tracking quality to stakeholders and to compare against competing systems or published benchmarks; without them, "how good is the tracker" has no common, externally comparable answer.

**How it's verified:** Run identical tracker output and ground truth through both the Rust implementation and `motmetrics` (`py-motmetrics`) in Python, and MATLAB's track-metric functions; compare resulting metric values.

**Definition of done:** Metric values within 1e-3.

**Data used:** Either public benchmark data (MOT16/17/20-format) or scenario-crate generated data — specifically validated against the dense-swarm scenario's high-density, high-ambiguity output, because these metrics are sensitive to identity-switch and fragmentation errors that are rare-to-nonexistent at low target density; at low density, a fragmentation count would just be a meaningless zero rather than a real signal.

**Risk if wrong:** Since these metrics are the primary way tracking quality gets reported externally, a computation bug here could mean the product is being marketed or benchmarked on numbers that don't actually reflect its real performance.

---

## Cross-Cutting Capabilities

### End-to-End Tracking Accuracy

**What it does:** Measures the accuracy of the complete tracking pipeline — not any single module — against externally validated public benchmarks, using OSPA/GOSPA (Optimal Sub-Pattern Assignment / its generalized variant) distance metrics.

**Why it matters:** This is the capability that answers the business-level question "does the whole system actually work," independent of whether any individual component's unit-level test passed — it's the check that catches integration issues that no single-module test could reveal.

**How it's verified:** Run the full pipeline against reference implementations (Stone Soup/`motpy`) on the same benchmark dataset; compare OSPA/GOSPA scores.

**Definition of done:** Within 5% of the reference implementation's OSPA/GOSPA score.

**Data used:** Public benchmarks only, deliberately — MOT16/17/20 (vision-level bounding boxes, which validates association and track-management logic more than filter math) and KITTI tracking (more structured automotive motion, a useful cross-check for the CV/CA/CT models specifically when targets are vehicle-like). This is intentionally kept separate from scenario-crate output, to avoid blurring "does our synthetic generator produce sound test cases" with "does the whole pipeline perform acceptably against independently validated real-world data."

**Risk if wrong:** This is the capability most visible to external stakeholders and most likely to be cited in comparisons against competing tracking systems; a regression here has direct reputational and competitive impact even if every individual module's tests are green.

### Numerical Stability Under Sustained Operation

**What it does:** Runs the full pipeline continuously for 10⁵+ cycles, asserting that covariance remains positive-semidefinite and no NaN/Inf values appear at every single step.

**Why it matters:** Some numerical failure modes — covariance drift, floating-point error accumulation — simply don't manifest in short test runs; they only appear after sustained operation, which is exactly the operating condition a production deployment will actually experience.

**How it's verified:** 10⁵+ cycle soak test with a per-step PSD and NaN/Inf assertion. This is a Rust-specific check with no Python or MATLAB equivalent — it's testing implementation robustness, not a modeling question with an external reference answer.

**Definition of done:** Zero PSD violations, zero NaN/Inf values, across the entire soak run.

**Data used:** Scenario-crate generated, specifically the adversarial/ill-conditioned geometry scenario — a well-conditioned scenario would never push the system toward the numerical edge this test exists to check.

**Risk if wrong:** This is the failure mode that's hardest to catch in normal development (short-lived test runs never encounter it) and most damaging in production (a long-running deployment that silently degrades has no natural point at which the problem becomes obvious before results are already wrong).

### Performance (Latency/Throughput)

**What it does:** Benchmarks the latency and throughput of critical code paths using `criterion`, compared against scripted reference runs in `filterpy`/`motpy` (Python, wall-clock) and MATLAB `codegen`-compiled C (context only, not a pass/fail target).

**Why it matters:** Correctness alone isn't sufficient for a real-time tracking system — a filter that's provably accurate but too slow to keep up with sensor rate is not deployable. This capability keeps performance visible as the system evolves, rather than letting it silently regress.

**How it's verified:** `criterion` benchmark runs compared against Python and MATLAB reference implementations for context.

**Definition of done:** Not pass/fail — the output is a comparative table in documentation, not a gate. (Benchmark *regression*, i.e., getting slower than the product's own prior version, is separately gated at the CI level via a hard-fail p99 regression check, per the workspace's `bench-regression.yml` workflow.)

**Data used:** Scenario-crate generated data, or public benchmark data, used purely as realistic-scale workloads for timing purposes rather than for correctness validation.

**Risk if wrong:** Because this row is explicitly not a pass/fail gate at the table level, the real risk is regression going unnoticed between releases if the separate CI regression gate isn't kept in sync with this row's intent.

### Scenario/Interop Schema (JSON/Arrow, ASTERIX/STANAG)

**What it does:** Validates that the shared data schema used for scenario/interop data (JSON/Arrow representations, and industry-standard ASTERIX/STANAG formats) round-trips through serialization and deserialization without data loss, and validates correctly against a corpus of real and synthetic scenarios.

**Why it matters:** ASTERIX and STANAG are established interoperability standards in the surveillance/defense tracking domain; correct schema handling is what lets this product exchange data with other systems and tooling in that ecosystem, not just operate as a closed system.

**How it's verified:** Round-trip serialize/deserialize, validated against a corpus of recorded and synthetic scenarios covering the schema's range.

**Definition of done:** Zero data loss on round-trip; 100% schema validation pass rate against the corpus.

**Data used:** A corpus of recorded and synthetic scenarios — chosen for breadth of format coverage rather than any single narrative scenario, since this is testing schema/serialization correctness rather than tracking behavior.

**Risk if wrong:** A schema bug specifically threatens interoperability with external systems and standards-compliance — a category of failure that may not surface internally at all (since the product's own read and write paths could be consistently wrong with each other) but would surface immediately when integrating with a third party's ASTERIX/STANAG-compliant system.

---

## How to read this document alongside the other two references

- **`scenario-crate-narrative.md`** explains *why* five specific scenarios were chosen and how they collectively cover the "Scenario-crate generated" rows above without requiring a bespoke generator per capability.
- **`verification-capability-table.md`** is the underlying source of truth this document expands — Rust module, oracle, verification method, and pass criteria for each row.
- **`gungnir-workspace-structure.md`** maps each of these capabilities to the actual crate that implements it and the CI workflow that enforces its verification gate.

This document adds the "why does the business care, and what breaks if it's wrong" layer that the other two intentionally leave out in favor of technical precision.
