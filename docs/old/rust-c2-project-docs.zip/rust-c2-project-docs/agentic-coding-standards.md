# Gungnir Agentic Coding & Architecture Standards

Companion reference to `gungnir-workspace-structure.md`, `verification-capability-table.md`,
`scenario-crate-narrative.md`, and `capability-descriptions.md`. This document is written
**for agents** (and their human reviewers) doing implementation work in the Gungnir workspace.
It fixes the stack — `nalgebra`, `tokio`, `serde`, `rand`, `proptest`, `criterion`, `arrow-rs`,
and `tracing` (approved per §2.8) — and defines how code built on that stack should be structured, written, and reviewed so that
output is consistent across crates and across agent sessions, not just individually correct.

Nothing here overrides the tiered agent trust model already established for the project
(`unsafe`, concurrency correctness, and numerical-stability guarantees remain human-owned).
This document is the *day-to-day style and architecture contract* that sits underneath that
trust model.

---

## 1. Architectural principles

### 1.1 Dependency direction is one-way and matches the crate graph

`gungnir-core` → `gungnir-coord` → `gungnir-filters` → `gungnir-association` →
`gungnir-track` → `gungnir-rfs` / `gungnir-track-fusion` → `gungnir-fusion-async` →
`gungnir-metrics`, with `gungnir-scenario` feeding test/bench code only (never a runtime
dependency of a production crate) and `gungnir-oracle` / `gungnir-testkit` / `gungnir-fuzz`
depending on everything but nothing depending on them.

An agent must not add a dependency edge that isn't already implied by this graph. If a task
seems to require one (e.g., `gungnir-filters` wanting something from `gungnir-association`),
that's a signal the abstraction is misplaced — stop and flag it rather than adding the edge.

### 1.2 Every public type has exactly one owning crate

No capability from the verification table is split across two crates' public APIs. If a type
needs to be shared (e.g., a `Track` struct used by both `track-manager` and `track-fusion`),
it lives in the crate lower in the dependency graph and is re-exported, never redefined.

### 1.3 Traits define the oracle-comparable surface

Every capability row in `verification-capability-table.md` corresponds to a trait, not just a
struct — `Filter`, `Associator`, `TrackFuser`, `CoordTransform`, etc. This is what lets
`gungnir-oracle` write one differential-test harness per trait rather than per concrete type,
and it's what lets `gungnir-testkit` express property tests generically over "any `Filter`
impl" instead of duplicating proptest strategies per filter.

```rust
// gungnir-filters/src/lib.rs
pub trait Filter {
    type State;
    type Measurement;
    fn predict(&mut self, dt: f64);
    fn update(&mut self, z: &Self::Measurement);
    fn state(&self) -> &Self::State;
}
```

Concrete filters (`KalmanFilter`, `ExtendedKalmanFilter`, `UnscentedKalmanFilter`, `Imm<M>`)
implement this trait. Oracle and property tests are written once against the trait.

### 1.4 No god-crates

If a crate's `lib.rs` module list stops mapping cleanly to a single row (or tight cluster of
rows) in the capability table, that's a signal it's grown beyond its scope. `gungnir-filters`
holding KF/EKF/UKF/PF/IMM/sqrt-UDU/RTS is intentional (they're one table section); it should
never also grow association or fusion logic.

### 1.5 Feature flags express oracle/verification opt-in, not runtime configuration

`nalgebra`, `tokio`, `serde` are always-on. Anything oracle-comparison-specific (e.g., a
`proptest`-only strategy module, or a `serde`-derived debug dump used only by
`gungnir-oracle`) is gated behind a `testkit` or `oracle` feature so production builds don't
carry verification scaffolding.

---

## 2. Stack-specific conventions

### 2.1 `nalgebra`

- **Fixed-size over dynamic wherever the dimension is known at compile time.** State vectors
  and covariance matrices for a specific motion model (`CV`, `CA`, `CT`) use `SVector<f64, N>`
  / `SMatrix<f64, N, N>`, not `DVector`/`DMatrix`. This is both a performance decision
  (stack allocation, no heap churn in the hot filter loop) and a correctness one — a
  dimension mismatch becomes a compile error instead of a runtime panic.
- **`DMatrix`/`DVector` are reserved for genuinely variable-cardinality state** — PHD/CPHD and
  GLMB/LMB, where the number of targets isn't known at compile time. Don't reach for dynamic
  matrices anywhere else out of convenience.
- **Never construct a covariance matrix without going through a constructor that asserts
  symmetry and PSD-ness in debug builds.** Every `Filter` impl's `new()` and every place a
  covariance is mutated in place should call a shared `assert_psd(&cov)` helper (debug-only,
  compiled out in release) from `gungnir-testkit`. This is cheap insurance against the exact
  failure mode `filters::sqrt/UDU` exists to prevent, and it should fire in *every* filter's
  tests, not just the sqrt-form one.
- **Decompositions used for correctness-critical paths (Cholesky for sqrt-form, QR/SVD for
  UDU) are always taken from `nalgebra`'s own implementations, never hand-rolled.** If a
  decomposition doesn't exist in `nalgebra` for what's needed, that's an escalation to a
  human, not a reason to write a custom one inline.
- **Units are documented in doc comments, not enforced by the type system**, since a full
  units crate (e.g., `uom`) is out of scope for this stack. Every public field or function
  argument that's a physical quantity states its unit explicitly: `/// range, meters`,
  `/// bearing, radians`. An agent adding a new public numeric field without a stated unit
  has produced incomplete work.

### 2.2 `tokio`

- **`fusion-async` is the only crate that depends on `tokio` for its runtime.** Other crates
  may use `tokio`'s non-runtime utilities (e.g., `tokio::sync` primitives) only if there's a
  concrete reason tied to the fusion-async data flow; otherwise they stay synchronous. A
  synchronous `Filter::update` call should never become `async fn` just because it's called
  from async code elsewhere — keep the async boundary at the I/O and scheduling layer
  (`fusion-async`), not inside pure computation.
- **No blocking work inside a `tokio` task without `spawn_blocking`.** Anything that does
  nontrivial matrix work (a PHD update over a large birth/clutter set, for instance) inside
  an async context must go through `tokio::task::spawn_blocking`, not run inline on the async
  executor thread.
- **Channels, not shared mutable state, for the OOS buffer and multi-rate scheduler.**
  `tokio::sync::mpsc` (or `broadcast` where multiple consumers genuinely need the same
  detection) is the default. Anywhere an agent finds itself reaching for `Arc<Mutex<...>>` to
  pass state between async tasks, that's the trigger to stop and get human review — this is
  exactly the code path `loom` and mandatory human sign-off exist for.
- **Every `async fn` in `fusion-async`'s public API takes a cancellation-safety note in its
  doc comment** (does it hold partial state across an `.await` point that would be corrupted
  by a dropped future?). This is cheap to write and expensive to reconstruct later.

### 2.3 `serde`

- **`#[derive(Serialize, Deserialize)]` on every type that crosses the scenario
  export/replay or oracle-comparison boundary** — this is a hard requirement, not a nice-to-
  have, since `gungnir-scenario`'s round-trip-fidelity row and `gungnir-oracle`'s comparison
  harness both depend on it.
- **No `#[serde(skip)]` on anything that affects verification-relevant state.** If a field is
  skipped, it must be reconstructible on deserialize (e.g., a cached derived value), and the
  reconstruction logic needs a comment explaining why skipping is safe.
- **Schema types (ASTERIX/STANAG, JSON/Arrow interop) live in their own module with `serde`
  attributes doing the format mapping explicitly** (`#[serde(rename = "...")]` etc.) rather
  than relying on Rust field names matching the wire format by coincidence. Field renames
  should be visible in the type definition, not hidden in a separate mapping table.

### 2.4 `rand`

- **Every stochastic component (particle filter resampling, scenario clutter/Pd sampling,
  RFS birth processes) takes an explicit `&mut impl Rng` parameter — never calls
  `rand::thread_rng()` internally.** This is what makes the statistical tests
  (`scenario`'s self-check, the particle filter's KS-test comparison) reproducible: tests
  seed a fixed `StdRng` or `ChaCha8Rng` and get deterministic output.
- **`rand_distr` for named distributions** (Normal, Poisson for clutter counts, etc.) rather
  than hand-rolled sampling from a uniform draw, except where a specific non-standard
  distribution is the point of the test.

### 2.5 `proptest`

- **Shared strategies live in `gungnir-testkit`, not duplicated per crate.** A "valid PSD
  covariance matrix of size N" strategy, a "well-formed CV/CA/CT trajectory" strategy, and a
  "cost matrix, optionally degenerate/rectangular" strategy are each written once and
  imported everywhere they're needed.
- **Every property test states the invariant it's checking in a doc comment or a
  `proptest!` block's leading comment**, not just in the function name — e.g., "covariance
  stays PSD across N predict/update cycles regardless of input measurement noise" rather than
  a bare `#[test] fn prop_psd()`.
- **Property tests are the default for anything with a mathematical invariant** (PSD-ness,
  probability-vector sums to 1, assignment respects one-to-one mapping); example-based unit
  tests are for known-input/known-output oracle comparisons. An agent writing only
  example-based tests for a filter or associator has under-tested it.

### 2.6 `criterion`

- **One benchmark group per hot path named after the capability row it measures**
  (`ekf_predict_update`, `hungarian_solve_100x100`, `phd_update_dense_swarm`), so
  `bench-regression.yml`'s output maps directly back to `verification-capability-table.md`
  without translation.
- **Benchmarks use `gungnir-scenario` output for realistic-scale inputs**, per the table's
  "Performance" row — not hand-picked toy inputs that don't represent real workload shape.
- **No benchmark asserts pass/fail on absolute numbers** (per the capability table, this row
  is explicitly not a pass/fail gate) — only the separate CI regression check compares
  against the prior release.

### 2.7 `arrow-rs`

- **Arrow schemas are defined once per interop boundary and shared between the writer and
  reader**, never independently reconstructed on each side — a single `schema()` function in
  the owning crate, imported by both directions.
- **ASTERIX/STANAG mapping code is isolated from the Arrow schema code.** They're two
  different interop concerns (industry format vs. internal columnar representation) and
  mixing them in one module makes the round-trip test in the capability table harder to
  reason about.

### 2.8 `tracing` (approved stack addition)

Logging/diagnostics wasn't part of the original fixed stack and was flagged for sign-off per
§6 rule 4. **Approved.** `tracing` (+ `tracing-subscriber`, and `tracing-appender` if
file-based capture is wanted for CI artifact upload) is now part of the standard Gungnir
stack alongside `nalgebra`, `tokio`, `serde`, `rand`, `proptest`, `criterion`, and
`arrow-rs` — the eight dependencies are the full fixed set as of this sign-off. The
conventions below are binding: crates should have no logging calls outside these
conventions, and `println!`/`eprintln!`/the `log` crate should not be reached for as
substitutes anywhere `tracing` conventions apply.

**Why `tracing` specifically, not `log`:** `fusion-async` is the one crate with genuine
concurrent, multi-stage execution (OOS buffer, multi-rate scheduler, multiple sensor feeds
in flight at once). `tracing`'s span model is what makes a log line traceable back to *which*
in-flight fusion task or *which* filter cycle produced it — a flat `log`-style line doesn't
carry that context across an `.await` point. `tracing`'s async-aware instrumentation
(`#[instrument]`, span-following across task boundaries) is built for exactly this problem,
and it composes with `tokio` directly (`tokio-console` and `tracing-subscriber` both consume
its output), so it doesn't introduce a second, uncoordinated diagnostics story alongside the
existing async runtime choice.

**Levels — used for their capability-table meaning, not generic severity:**

- `error!` — reserved for the things the capability table treats as hard failures: a PSD
  violation, a NaN/Inf in a covariance or state vector, a `loom`-detected race surfaced at
  runtime outside the test harness, an association solver returning an infeasible assignment.
  An `error!` in Gungnir should always correspond to a definition-of-done criterion being
  violated, not general-purpose "something looked off."
- `warn!` — degraded-but-recoverable conditions the table treats as expected edge cases:
  a track entering coast state, a gate rejecting all candidate detections for a cycle, a
  sensor's OOS buffer approaching its configured depth limit.
- `info!` — capability-table-visible lifecycle events: track init/confirm/delete transitions,
  IMM mode switches, scenario generation start/end. Sparse enough that a human tailing
  production logs gets a readable narrative of what the tracker is doing, not a firehose.
- `debug!` — pipeline-stage detail useful when reproducing a specific test failure: per-cycle
  predict/update calls, association cost-matrix dimensions, fusion input track counts. Off by
  default; enabled per-crate when debugging a specific oracle mismatch.
- `trace!` — full numeric dumps (state vectors, covariance matrices, cost matrices). Gated
  behind a `trace-numeric` feature flag in addition to the log-level filter, since these lines
  are expensive to format and privacy/size-irrelevant here but still not something to pay for
  in a release build even when the level is filtered — the feature flag keeps the formatting
  code out of the binary entirely when unused.

**Spans, not ad hoc context strings:** every `Filter::predict`/`update`, `Associator::solve`,
and `fusion-async` task uses `#[instrument]` (or an explicit `tracing::span!` where
`#[instrument]`'s auto-derived fields aren't the right shape) rather than folding identifying
context into the log message text. Structured fields use the same names as the capability
table and the error-enum conventions in §3.1 (`cycle`, `track_id`, `min_eigenvalue`,
`sensor_id`) so a span's fields, an error variant's fields, and a proptest failure's shrunk
input can all be cross-referenced by the same names.

```rust
#[tracing::instrument(skip(self, z), fields(track_id = self.id))]
fn update(&mut self, z: &Measurement) {
    if let Some(min_eig) = self.covariance.min_eigenvalue_if_below_threshold() {
        tracing::error!(min_eigenvalue = min_eig, "covariance PSD violation");
    }
    // ...
}
```

**No logging in `core`, `coord`, or `allocation`.** These are the exact-match,
closed-form-oracle capabilities (§ table notes) — deterministic math with a single correct
answer doesn't benefit from runtime diagnostics, and adding spans there is noise that would
never get read. Tracing effort is concentrated in `filters`, `association`, `rfs`,
`fusion-async`, and `track-manager`, where behavior is statistical, stateful, or
timing-sensitive enough that a human debugging a failure actually needs the trail.

**Test and CI integration:** `gungnir-oracle`'s differential-test harness captures the
`trace!`-level span output (via `tracing-subscriber`'s `EnvFilter` and a test-scoped
subscriber, not a global one — global subscribers in test code cause cross-test interference)
for any comparison that fails, and attaches it to the CI failure artifact. This means a failed
oracle-diff run comes with the actual predict/update sequence that produced the mismatch,
rather than requiring the failure to be reproduced locally with logging manually turned on
after the fact.

**What this section does not cover:** metrics/observability for a production deployment
(dashboards, alerting thresholds) is out of scope for a library — Gungnir emits `tracing`
spans and events; what a downstream binary does with them (write to a file, forward to an
OpenTelemetry collector, ignore them entirely) is the downstream application's decision, not
something this workspace should couple itself to.

---

## 3. General Rust standards

### 3.1 Errors

- Every fallible public function returns `Result<T, E>` with a crate-local error enum
  (`thiserror`-style manual `impl std::error::Error`, kept dependency-free per the fixed
  stack — a `thiserror` addition is a stack change and needs explicit sign-off, not an
  agent's unilateral choice).
- `unwrap()` / `expect()` are permitted only in: test code, `main()`/example binaries, and
  `debug_assert!`-style internal invariant checks explicitly gated to debug builds. Any other
  `unwrap()` in library code is a defect, not a style nit — flag it in review.
- Errors carry enough context to reconstruct which oracle-comparison row failed and why
  (e.g., `FilterError::CovarianceNotPsd { cycle: usize, min_eigenvalue: f64 }`), since these
  messages end up in CI logs that a human is debugging against the capability table.

### 3.2 Naming

- Types match the capability table's terminology exactly (`ExtendedKalmanFilter`, not `Ekf`
  or `EKFilter`) so that grep-ing the table's language against the codebase works.
- Generic parameters are named for what they represent, not just `T`/`U` — `Filter<S: State>`
  reads better than `Filter<T>` in a numerically dense codebase where the reader is already
  tracking several type parameters.

### 3.3 Module structure within a crate

- `lib.rs` re-exports the public trait(s) and top-level types; implementation detail lives in
  submodules named after the capability, not generic names like `impl.rs` or `utils.rs`.
- Every submodule that corresponds to a capability-table row opens with a doc comment linking
  back to the row: `//! Verifies against verification-capability-table.md: "Extended Kalman
  Filter (EKF)". Relative error < 1e-4 vs. filterpy/trackingEKF.`

### 3.4 Documentation

- Every public item has a doc comment. For anything appearing in the capability table, the
  doc comment states the pass criterion inline, so the two documents never drift silently out
  of sync.
- Doc examples (`/// ```` blocks) are required on every public trait and are run as doctests —
  they double as cheap regression coverage for the API surface.

### 3.5 Lints

- `#![deny(unsafe_op_in_unsafe_fn)]` workspace-wide.
- `#![warn(clippy::all, clippy::pedantic)]` with an explicit, commented allow-list per crate
  for pedantic lints that don't fit numerical code (e.g., `clippy::many_single_char_names` is
  reasonably allowed in matrix-heavy modules where `f`, `q`, `h`, `r` are the standard filter
  notation — but the allow needs a one-line justification, not a blanket suppression).
- `cargo fmt` is non-negotiable and runs in `ci.yml` on every PR; agents should not hand-format
  code differently from what `rustfmt` would produce.

---

## 4. `unsafe` policy

Per the existing tiered trust model: agents may **propose** `unsafe` code (e.g., for a
performance-critical SIMD path in a hot filter loop) but every such block:

- Is isolated to the smallest possible scope, wrapped in a safe function with documented
  preconditions (`# Safety` doc section — mandatory, not optional).
- Triggers `miri.yml` automatically and requires human sign-off before merge, per the
  workspace's CI gate mapping — an agent should never merge its own `unsafe` code, and should
  say so explicitly in the PR description rather than assuming the reviewer will notice.
- Is justified with a benchmark showing the safe alternative was measured and found
  insufficient — `unsafe` for unmeasured, assumed performance gain is not acceptable.

## 5. Concurrency policy

Same posture as `unsafe`: agents may write `fusion-async` code, including code using
`tokio::sync` primitives, but:

- Any PR touching `gungnir-fusion-async` triggers `loom.yml` automatically.
- The PR description must state, in plain language, what interleaving the change could
  introduce or affect — this is for the human reviewer's benefit and should not be skipped
  even when the change looks small.
- Human sign-off is mandatory before merge regardless of green CI, per the existing gate.

---

## 6. Agent operating rules

1. **Read the capability table row before writing the code**, not after. The pass criterion
   should shape the implementation (e.g., knowing IMM's tolerance is on mode probabilities as
   well as state should influence how mode probability normalization is implemented, not be
   discovered afterward when a test fails).
2. **Write the oracle-comparison test alongside the implementation**, in the same PR, not as
   follow-up work. A capability without a passing differential test against its named oracle
   is not done, regardless of how complete the implementation looks.
3. **Never widen a pass criterion to make a test pass.** If relative error is coming in at
   1e-3 against an EKF's 1e-4 requirement, the fix is in the implementation (or an escalation
   explaining why the criterion itself needs revisiting), not a quiet tolerance edit.
4. **Flag architectural questions instead of guessing.** If a task seems to require crossing
   a dependency-graph boundary (§1.1) or adding a new stack dependency beyond the fixed eight
   (§2.1–§2.8), stop and ask rather than proceeding on an assumption.
5. **Self-review against this document before requesting human review** — specifically the
   `unwrap()` policy (§3.1), the `nalgebra` fixed-vs-dynamic rule (§2.1), and the `tokio`
   blocking-work rule (§2.2), since these are the three most common places agent-written
   numerical/async code tends to drift from the standard.

---

## Cross-references

- `verification-capability-table.md` — the pass criteria this document's conventions exist to
  make easy to satisfy and easy to verify.
- `scenario-crate-narrative.md` — why the five scenarios exist; §2.5/§2.4 here explain how
  test code should consume that generator's output deterministically.
- `gungnir-workspace-structure.md` — the crate graph §1.1 formalizes into a dependency rule,
  and the CI gate table §4/§5 here point back to directly.
- `capability-descriptions.md` — the "why it matters" layer that motivates why some of these
  standards (unit documentation, PSD assertions, deterministic RNG) exist as hard requirements
  rather than style preferences.
