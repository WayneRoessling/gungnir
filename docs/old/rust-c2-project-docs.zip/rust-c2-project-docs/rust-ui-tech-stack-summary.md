# Rust UI Technology Stack — Summary

**Context:** Selecting a Rust-based UI/rendering stack for a Windows 11 desktop application, targeting an NVIDIA GeForce RTX 5090 GPU. Application modules discussed as UI surfaces: dashboards, situational-awareness views, and interactive panel-based controls.

> **Scope note:** This document covers only the *UI and rendering framework* discussion — it does not contain, and this thread did not produce, any system design, algorithms, sensor integration, control logic, or engineering detail for the underlying application functionality. Framework choices below are purely about how to build windows, panels, 3D viewports, and controls on screen.

---

## 1. Rust GUI Landscape (General)

Rust has no built-in GUI toolkit; the ecosystem provides several mature third-party options:

| Category | Libraries |
|---|---|
| Immediate-mode GUI | egui |
| Declarative/Elm-style | iced, Xilem |
| Markup-based declarative | Slint |
| Native bindings | gtk-rs, relm4 (GTK4) |
| Web-view desktop | Tauri (Rust backend + HTML/CSS/JS frontend) |
| Web/WASM frontends | Yew, Leptos, Dioxus, Sycamore |

## 2. Windows 11 + RTX GPU Considerations

For GPU-accelerated rendering on Windows, the relevant backend is **`wgpu`**, which maps to **DirectX 12** on Windows and lets the application take advantage of RTX-class hardware.

- **egui + eframe (wgpu backend)** — immediate-mode, fast to build with, well suited to live-updating dashboard panels, telemetry readouts, and control widgets.
- **iced** — also wgpu-based; more structured, declarative app architecture (Elm-like), good fit if the application benefits from stricter state management across many views.
- **Slint** — declarative UI with a more native-Windows look and feel; alternative renderer options.

## 3. 3D Visualization Layer (Meshes / Surfaces)

For any panel requiring a 3D viewport (e.g., a spatial/situational display rendering terrain, geometry, or surface data):

- **`three-d`** — Recommended starting point. Built on `wgpu` (DX12 acceleration), includes meshes, lighting, camera controls (orbit/pan/zoom), and picking out of the box. Lighter weight than a full game engine.
- **Bevy** — Alternative if the application is expected to grow into something with more complex scene/entity management, animation, or plugin-style architecture. ECS-based, also `wgpu`/DX12-backed, integrates with `bevy_egui` for overlay UI.

Both integrate cleanly with `egui` for overlay controls (view mode toggles, color-scale/legend controls, camera reset, filtering panels, etc.).

## 4. Recommended Stack (Starting Point)

| Layer | Recommendation |
|---|---|
| Windowing / app shell | `eframe` (egui) or `iced` |
| 2D dashboard panels & controls | `egui` |
| 3D viewport (spatial/situational views) | `three-d` (or `Bevy` if scene complexity grows) |
| GPU backend | `wgpu` → DirectX 12 (RTX 5090 acceleration) |

**Suggested first step:** prototype the dashboard shell in `egui`/`eframe`, and stand up a single 3D viewport panel using `three-d` to validate the rendering pipeline before building out additional views.

## 5. Open Questions for Next Steps

- Data sources and update cadence for dashboard panels (polling vs. push/streaming)
- Number and layout of simultaneous views/panels (single window with docking vs. multi-window)
- Whether 3D views need to render point clouds, meshes/surfaces, or both
- Any existing design system / branding constraints for a native-Windows look and feel

---

*This document reflects only the frontend/rendering technology discussion from this conversation. No application logic, data models, networking, or control-system design was discussed or is included here.*
